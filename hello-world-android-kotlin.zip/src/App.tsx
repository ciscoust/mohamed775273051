import { useState } from "react";
import { 
  FileCode, 
  Settings, 
  FileJson, 
  Layout, 
  Smartphone, 
  CheckCircle2, 
  Copy, 
  ArrowRight,
  FolderOpen
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const files = [
    { name: "settings.gradle", path: "root/", type: "gradle" },
    { name: "build.gradle", path: "root/", type: "gradle" },
    { name: "gradle-wrapper.properties", path: "gradle/wrapper/", type: "props" },
    { name: "app/build.gradle", path: "app/", type: "gradle" },
    { name: "AndroidManifest.xml", path: "app/src/main/", type: "xml" },
    { name: "MainActivity.kt", path: "app/src/main/java/.../", type: "kotlin", active: true },
    { name: "activity_main.xml", path: "app/src/main/res/layout/", type: "xml" },
  ];

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-50 font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-72 border-r border-slate-200 bg-slate-100 flex flex-col shrink-0">
        <div className="p-5 border-b border-slate-200 bg-slate-800 text-white">
          <div className="flex items-center gap-2 mb-1">
            <Smartphone className="w-4 h-4 text-blue-400" />
            <h1 className="text-sm font-bold tracking-tight uppercase">Android Scaffold</h1>
          </div>
          <p className="text-[10px] opacity-70 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-green-400" />
            GitHub Actions Optimized
          </p>
        </div>
        
        <nav className="flex-1 py-4 text-xs overflow-y-auto">
          <div className="px-5 mb-3 text-slate-500 font-bold uppercase tracking-wider text-[9px] flex items-center gap-2">
            <FolderOpen className="w-3 h-3" />
            Project Structure
          </div>
          <ul className="space-y-px">
            {files.map((file, idx) => (
              <li 
                key={file.name}
                className={`px-5 py-2.5 cursor-pointer transition-colors flex flex-col ${
                  file.active 
                  ? "bg-blue-50 border-r-4 border-blue-500 text-blue-700 font-medium" 
                  : "hover:bg-slate-200 text-slate-600"
                }`}
              >
                <span className="block text-[10px] opacity-60 italic font-mono truncate">{file.path}</span>
                <span className="flex items-center gap-2">
                  {file.type === "kotlin" && <FileCode className="w-3.5 h-3.5 text-blue-500" />}
                  {file.type === "xml" && <Layout className="w-3.5 h-3.5 text-orange-500" />}
                  {file.type === "gradle" && <Settings className="w-3.5 h-3.5 text-slate-400" />}
                  {file.type === "props" && <FileJson className="w-3.5 h-3.5 text-slate-400" />}
                  {file.name}
                </span>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 bg-slate-200 border-t border-slate-300">
          <div className="flex items-center gap-2 text-[10px] text-slate-600 font-semibold">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            BUILD READY (GRADLE 8.0)
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50">
        {/* Header */}
        <header className="h-12 border-b border-slate-200 bg-white flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-2 text-sm text-slate-600 overflow-hidden">
            <span className="text-slate-400 font-mono text-[11px] truncate hidden sm:inline">
              app / src / main / java / com / example / myapp /
            </span>
            <ArrowRight className="w-3 h-3 text-slate-300 hidden sm:inline" />
            <span className="font-bold flex items-center gap-2">
              <FileCode className="w-4 h-4 text-blue-500" />
              MainActivity.kt
            </span>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => copyToClipboard(`package com.example.myapp\n\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\n\nclass MainActivity : AppCompatActivity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContentView(R.layout.activity_main)\n    }\n}`, "main")}
              className="group relative px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-[11px] font-bold transition-all flex items-center gap-2"
            >
              <AnimatePresence mode="wait">
                {copied === "main" ? (
                  <motion.span 
                    key="copied"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3 h-3 text-green-400" />
                    COPIED
                  </motion.span>
                ) : (
                  <motion.span 
                    key="copy"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    COPY CODE
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>
        </header>

        {/* Editor Area */}
        <div className="flex-1 p-6 grid grid-rows-2 gap-6 overflow-hidden">
          
          {/* Top Pane: Kotlin Source */}
          <section className="bg-slate-900 rounded-xl shadow-2xl border border-slate-800 flex flex-col overflow-hidden group">
            <div className="flex px-4 py-2 border-b border-slate-800 bg-slate-800/50 justify-between items-center shrink-0">
              <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                Kotlin Source
              </div>
              <button 
                onClick={() => copyToClipboard(`package com.example.myapp\n\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\n\nclass MainActivity : AppCompatActivity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContentView(R.layout.activity_main)\n    }\n}`, "source")}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-slate-700 rounded transition-all"
              >
                <Copy className="w-3 h-3 text-slate-400" />
              </button>
            </div>
            <div className="p-6 font-mono text-[13px] leading-relaxed overflow-y-auto custom-scrollbar">
              <pre className="text-slate-300">
                <code className="block">
                  <span className="text-blue-400">package</span> com.example.myapp{"\n\n"}
                  <span className="text-purple-400">import</span> android.os.Bundle{"\n"}
                  <span className="text-purple-400">import</span> androidx.appcompat.app.AppCompatActivity{"\n\n"}
                  <span className="text-purple-400">class</span> <span className="text-yellow-300">MainActivity</span> : <span className="text-yellow-300">AppCompatActivity</span>() {"{"}{"\n"}
                  {"    "}<span className="text-purple-400">override fun</span> <span className="text-green-400">onCreate</span>(savedInstanceState: Bundle?) {"{"}{"\n"}
                  {"        "}<span className="text-blue-300">super</span>.onCreate(savedInstanceState){"\n"}
                  {"        "}setContentView(R.layout.activity_main){"\n"}
                  {"    "}{"}"}{"\n"}
                  {"}"}
                </code>
              </pre>
            </div>
          </section>

          {/* Bottom Pane Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden">
            {/* Manifest */}
            <article className="bg-slate-900 rounded-xl border border-slate-800 flex flex-col overflow-hidden">
              <div className="px-4 py-2 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                  <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                  AndroidManifest.xml
                </div>
              </div>
              <div className="p-4 font-mono text-[11px] leading-tight text-slate-400 overflow-y-auto custom-scrollbar">
                <pre>
                  <code>
                    &lt;<span className="text-blue-400">manifest</span> <span className="text-purple-400">xmlns:android</span>="..."&gt;{"\n"}
                    {"  "}&lt;<span className="text-blue-400">application</span>{"\n"}
                    {"    "}android:label="<span className="text-green-400">@string/app_name</span>"&gt;{"\n"}
                    {"    "}&lt;<span className="text-blue-400">activity</span> <span className="text-purple-400">android:name</span>="<span className="text-green-300">.MainActivity</span>"&gt;{"\n"}
                    {"      "}&lt;intent-filter&gt;{"\n"}
                    {"        "}&lt;action android:name="android.intent.action.MAIN" /&gt;{"\n"}
                    {"        "}&lt;category android:name="android.intent.category.LAUNCHER" /&gt;{"\n"}
                    {"      "}&lt;/intent-filter&gt;{"\n"}
                    {"    "}&lt;/activity&gt;{"\n"}
                    {"  "}&lt;/application&gt;{"\n"}
                    &lt;/manifest&gt;
                  </code>
                </pre>
              </div>
            </article>

            {/* Layout */}
            <article className="bg-slate-900 rounded-xl border border-slate-800 flex flex-col overflow-hidden">
              <div className="px-4 py-2 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  activity_main.xml
                </div>
              </div>
              <div className="p-4 font-mono text-[11px] leading-tight text-slate-400 overflow-y-auto custom-scrollbar">
                <pre>
                  <code>
                    &lt;<span className="text-blue-400">TextView</span>{"\n"}
                    {"  "}android:<span className="text-purple-400">layout_width</span>="wrap_content"{"\n"}
                    {"  "}android:<span className="text-purple-400">layout_height</span>="wrap_content"{"\n"}
                    {"  "}android:<span className="text-purple-400">text</span>="<span className="text-green-400">Hello World!</span>"{"\n"}
                    {"  "}app:<span className="text-purple-400">layout_constraintBottom_toBottomOf</span>="parent"{"\n"}
                    {"  "}app:<span className="text-purple-400">layout_constraintTop_toTopOf</span>="parent" /&gt;
                  </code>
                </pre>
              </div>
            </article>
          </div>
        </div>

        {/* Status Bar */}
        <footer className="h-8 border-t border-slate-200 bg-white flex items-center px-6 justify-between text-[10px] text-slate-500 uppercase tracking-widest shrink-0">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="opacity-50 font-semibold">TARGET SDK:</span> 34
            </div>
            <div className="flex items-center gap-2">
              <span className="opacity-50 font-semibold">KOTLIN:</span> 1.9.0
            </div>
            <div className="flex items-center gap-2">
              <span className="opacity-50 font-semibold">GRADLE:</span> 8.0
            </div>
          </div>
          <div className="flex items-center gap-2 font-bold text-slate-400 italic">
            <Smartphone className="w-3 h-3" />
            BUILD-SAFE CONFIGURATION
          </div>
        </footer>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.02);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}
